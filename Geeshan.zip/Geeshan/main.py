from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import json
import os

app = FastAPI()

# Serve Vite assets
app.mount("/assets", StaticFiles(directory="dist/assets"), name="assets")

DATA_FILE = "data.json"

if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as f:
        json.dump({"tasks": [], "behavior_logs": []}, f)

def load_data():
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

@app.get("/api/tasks")
def get_tasks():
    return load_data()

@app.post("/api/tasks")
async def add_task(request: Request):
    data = load_data()
    new_task = await request.json()
    data["tasks"].append(new_task)
    save_data(data)
    return {"status": "task added"}

@app.post("/api/behavior")
async def add_behavior(request: Request):
    data = load_data()
    new_log = await request.json()
    data["behavior_logs"].append(new_log)
    save_data(data)
    return {"status": "behavior logged"}

# Serve React (Vite)
@app.get("/{full_path:path}")
def serve_react():
    return FileResponse("dist/index.html")